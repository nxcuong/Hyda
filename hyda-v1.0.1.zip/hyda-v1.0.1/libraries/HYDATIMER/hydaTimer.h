/*
 * Copyright (c) 2021, TC LIFTING EQUIPMENT CO., LTD
 * All rights reserved.
 */

#ifndef __HYDATIMER_H__
#define __HYDATIMER_H__
#include <Arduino.h>

//global variables
//use as global variable for all Timer!
//extern unsigned long hydaLastTime;
extern unsigned long hydaCycleTime;

//timer type, update v1. has enable variable for enable timer, if en = false, reset all.
typedef struct {
    bool	        en;     //digital input, Timer enable
    bool	        in;     //digital input, start the timer
    unsigned long	pt;     //period time = after pt time, the out trigger ON state.
    unsigned long    et;   //ELAPSE TIME = counting timer by adding cycle time when the function was called each cycle of mcu
    bool            out;    //timer out signal
} hydTimer;

//timer functions
hydTimer TON(hydTimer);
hydTimer TOFF(hydTimer);
hydTimer TP(hydTimer);
//bool TFLASH(unsigned long, bool); //flashing 
hydTimer TFLASH(hydTimer*);
hydTimer nTSP(hydTimer tsp, unsigned int tON, unsigned int tOFF);
hydTimer TSP(hydTimer*, unsigned int, unsigned int);         //pulse ON and OFF
hydTimer TDP(hydTimer* tmp, unsigned int ton1, unsigned int toff1, unsigned n1, unsigned int ton2, unsigned int toff2, unsigned int n2);
#endif