/*
HYDAMOTION DIGITAL MODULE LIBRARY
Base on the MCP23S17 library
TC LIFTING EQUIPMENT CO., LTD
https://tcevn.vn
*/

#include <SPI.h>                // Arduino IDE SPI library 
#include <diConfig.h>

#ifndef HIGH
#define    HIGH          (1)
#endif

#ifndef LOW
#define    LOW           (0)
#endif

#ifndef ON
#define    ON            (1)
#endif

#ifndef OFF
#define    OFF           (0)
#endif

#ifndef INPUT
#define    INPUT           (1)
#endif

#ifndef OUTPUT
#define    OUTPUT           (0)
#endif

//==============================================================

// Here we have things for the SPI bus configuration

#define    CLOCK_DIVIDER (2)           // SPI bus speed to be 1/2 of the processor clock speed - 8MHz on most Arduinos

// Control byte and configuration register information - Control Byte: "0100 A2 A1 A0 R/W" -- W=0

#define    OPCODEW       (0b01000000)  // Opcode for DIMO23S17 with LSB (bit0) set to write (0), address OR'd in later, bits 1-3
#define    OPCODER       (0b01000001)  // Opcode for DIMO23S17 with LSB (bit0) set to read (1), address OR'd in later, bits 1-3
#define    ADDR_ENABLE   (0b00001000)  // Configuration register for DIMO23S17, the only thing we change is enabling hardware addressing
#define    PINMODE_VAL_EX08    (0B0000000011111111)

DIMO::DIMO(uint8_t type, uint8_t ss) {      //type of module 16DI, 8DI8DO, 16DO

    DIMO1(0, ss);
    _moduleType = type;

};

void DIMO::DIMO1(uint8_t address, uint8_t ss) {
    _address = constrain(address, 0, 7);
    _ss = ss;
    _modeCache = 0xFFFF;                // Default I/O mode is all input, 0xFFFF
    _outputCache = 0x0000;                // Default output state is all off, 0x0000
    _pullupCache = 0x0000;                // Default pull-up state is all off, 0x0000
    _invertCache = 0x0000;                // Default input inversion state is not inverted, 0x0000

}

void DIMO::setup() {
    ::pinMode(_ss, OUTPUT);               // Set SlaveSelect pin as an output
    ::digitalWrite(_ss, HIGH);            // Set SlaveSelect HIGH (chip de-selected)
    SPI.begin();
    SPI.beginTransaction(SPISettings(10000000, MSBFIRST, SPI_MODE0)); // them dong setting cho SPI
                              // Start up the SPI bus
    //SPI.setClockDivider(CLOCK_DIVIDER); // Sets the SPI bus speed
    //SPI.setBitOrder(MSBFIRST);          // Sets SPI bus bit order (this is the default, setting it for good form!)
    //SPI.setDataMode(SPI_MODE0);         // Sets the SPI bus timing mode (this is the default, setting it for good form!)
    byteWrite(IOCON, ADDR_ENABLE);
    if (_moduleType == 3) {//module DO16
        pinMode(0x00); //16out
    }
    else if (_moduleType == 2) {
        pinMode(PINMODE_VAL_EX08); //EX88 8in, 8out
    }
    else if(_moduleType == 1)
    {
        pinMode(0xFF); //DI16 in
    }
    else {
        //do nothing!
    }
    
    
    //pinMode(PINMODE_VAL_EX08); //8in, 8out
}

// GENERIC BYTE WRITE - will write a byte to a register, arguments are register address and the value to write

void DIMO::byteWrite(uint8_t reg, uint8_t value) {      // Accept the register and byte
    ::digitalWrite(_ss, LOW);                            // Take slave-select low
    SPI.transfer(OPCODEW | (_address << 1));             // Send the DIMO23S17 opcode, chip address, and write bit
    SPI.transfer(reg);                                   // Send the register we want to write
    SPI.transfer(value);                                 // Send the byte
    ::digitalWrite(_ss, HIGH);                           // Take slave-select high
}

// GENERIC WORD WRITE - will write a word to a register pair, LSB to first register, MSB to next higher value register 

void DIMO::wordWrite(uint8_t reg, unsigned int word) {  // Accept the start register and word 
    ::digitalWrite(_ss, LOW);                            // Take slave-select low
    SPI.transfer(OPCODEW | (_address << 1));             // Send the DIMO23S17 opcode, chip address, and write bit
    SPI.transfer(reg);                                   // Send the register we want to write 
    SPI.transfer((uint8_t)(word));                      // Send the low byte (register address pointer will auto-increment after write)
    SPI.transfer((uint8_t)(word >> 8));                 // Shift the high byte down to the low byte location and send
    ::digitalWrite(_ss, HIGH);                           // Take slave-select high
}

// MODE SETTING FUNCTIONS - BY PIN AND BY WORD

void DIMO::pinMode(uint8_t pin, uint8_t mode) {  // Accept the pin # and I/O mode
    if (pin < 1 || pin > 16) return;               // If the pin value is not valid (1-16) return, do nothing and return
    if (mode == INPUT) {                          // Determine the mode before changing the bit state in the mode cache
      //_modeCache |= _BV(pin - 1);               // Since input = "HIGH", OR in a 1 in the appropriate place
        _modeCache |= 1 << (pin - 1);
    }
    else if (mode == OUTPUT) {
        // _modeCache &= ~(_BV(pin - 1));            // If not, the mode must be output, so and in a	 0 in the appropriate place
        _modeCache &= ~(1 << (pin - 1));
    }
    wordWrite(IODIRA, _modeCache);                // Call the generic word writer with start register and the mode cache
}

void DIMO::pinMode(unsigned int mode) {     // Accept the word�
    wordWrite(IODIRA, mode);                 // Call the the generic word writer with start register and the mode cache
    _modeCache = mode;
}

// THE FOLLOWING WRITE FUNCTIONS ARE NEARLY IDENTICAL TO THE FIRST AND ARE NOT INDIVIDUALLY COMMENTED

// WEAK PULL-UP SETTING FUNCTIONS - BY WORD AND BY PIN

void DIMO::pullupMode(uint8_t pin, uint8_t mode) {
    if (pin < 1 || pin > 16) return;
    if (mode == ON) {
        _pullupCache |= 1 << (pin - 1);
    }
    else {
        _pullupCache &= ~(1 << (pin - 1));
    }
    wordWrite(GPPUA, _pullupCache);
}


void DIMO::pullupMode(unsigned int mode) {
    wordWrite(GPPUA, mode);
    _pullupCache = mode;
}


// INPUT INVERSION SETTING FUNCTIONS - BY WORD AND BY PIN

void DIMO::inputInvert(uint8_t pin, uint8_t mode) {
    if (pin < 1 || pin > 16) return;
    if (mode == ON) {
        _invertCache |= 1 << (pin - 1);
    }
    else {
        _invertCache &= ~(1 << (pin - 1));
    }
    wordWrite(IPOLA, _invertCache);
}

void DIMO::inputInvert(unsigned int mode) {
    wordWrite(IPOLA, mode);
    _invertCache = mode;
}


// WRITE FUNCTIONS - BY WORD AND BY PIN

void DIMO::digitalWrite(uint8_t pin, uint8_t value) {
    //unsigned int temp = ~(1 << (pin - 1));

    if (pin < 1 || pin > 16) return;
    //if (pin < 1 | pin > 16) return;
    if (value) {
        _outputCache |= 1 << (pin - 1);
    }
    else {

        //_outputCache &= (0 << (pin - 1));
        _outputCache &= ~(1 << (pin - 1)); //fixed by Demen
    }
    wordWrite(GPIOA, _outputCache);
    //byteWrite(GPIOA, uint8_t(_outputCache));
    //byteWrite(GPIOB, uint8_t(_outputCache >> 8));
}

void DIMO::digitalWrite(unsigned int value) {
    wordWrite(GPIOA, value);
    _outputCache = value;
}


// READ FUNCTIONS - BY WORD, BYTE AND BY PIN

unsigned int DIMO::digitalRead(void) {       // This function will read all 16 bits of I/O, and return them as a word in the format 0x(portB)(portA)
    unsigned int value = 0;                   // Initialize a variable to hold the read values to be returned
    ::digitalWrite(_ss, LOW);                 // Take slave-select low
    SPI.transfer(OPCODER | (_address << 1));  // Send the DIMO23S17 opcode, chip address, and read bit
    SPI.transfer(GPIOA);                      // Send the register we want to read
    value = SPI.transfer(0x00);               // Send any byte, the function will return the read value (register address pointer will auto-increment after write)
    value |= (SPI.transfer(0x00) << 8);       // Read in the "high byte" (portB) and shift it up to the high location and merge with the "low byte"
    ::digitalWrite(_ss, HIGH);                // Take slave-select high
    return value;                             // Return the constructed word, the format is 0x(portB)(portA)
}

uint8_t DIMO::byteRead(uint8_t reg) {        // This function will read a single register, and return it
    uint8_t value = 0;                        // Initialize a variable to hold the read values to be returned
    ::digitalWrite(_ss, LOW);                 // Take slave-select low
    SPI.transfer(OPCODER | (_address << 1));  // Send the DIMO23S17 opcode, chip address, and read bit
    SPI.transfer(reg);                        // Send the register we want to read
    value = SPI.transfer(0x00);               // Send any byte, the function will return the read value
    ::digitalWrite(_ss, HIGH);                // Take slave-select high
    return value;                             // Return the constructed word, the format is 0x(register value)
}

uint8_t DIMO::digitalRead(uint8_t pin) {                    // Return a single bit value, supply the necessary bit (1-16)
    if (pin < 1 || pin > 16) return 0x0;                    // If the pin value is not valid (1-16) return, do nothing and return
    return digitalRead() & (1 << (pin - 1)) ? HIGH : LOW;  // Call the word reading function, extract HIGH/LOW information from the requested pin

}