/*
 * by TC LIFTING EQUIPMENT CO., LTD
 * all definition of hydramega family boards
 */

#ifndef HYDA_H_INCLUDED
#define HYDA_H_INCLUDED


#include "Arduino.h"

//=============================
void hydaHardwareConfig();
void hydaInit();


#endif