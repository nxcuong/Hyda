/*
 * Copyright (c) 2021, TC LIFTING EQUIPMENT CO., LTD
 * All rights reserved.
 */

#ifndef __HYDAFUNC_H__
#define __HYDAFUNC_H__
#include <Arduino.h>
#include <hyda.h>	//header file of hyda family


unsigned char DIN(unsigned char channelNumber);   //INPUTS READ
/*
can use direct number 1 - 8
return value of this function is signal of input channel = LOW or HIGH
*/
void DOUT(uint8_t channel, uint8_t value);   //OUTPUTS AS ON/OFF
/*
use direct number 1 to 8 for hyda
*/
void PWMOUT(uint8_t channelNumber, float duty);   //PWM OUT
/*
function to do PWM on output channels 1-10
*/
unsigned int AIN(unsigned char channelNumber); //ANALOG READ to make distinction with original aduino analogRead()

unsigned int CUR(unsigned char channelNumber); //function to read current sense of digital out channels
//and iSense from 1-12 of mega1612
//status of DOs
unsigned char STA(unsigned char channelNo);
void t1Config();
void t3Config();    //fix frequency output!
void t4Config();    //fix frequency output!
void t5Config();    //fix frequency output!
void PWM1_SETUP(unsigned int pwmFreq);    //frequency will be set in function
void PWM3_SETUP(unsigned int pwmFreq);    //frequency will be set in function
void PWM4_SETUP(unsigned int pwmFreq);    //frequency will be set in function
void PWM5_SETUP(unsigned int pwmFreq);
#endif