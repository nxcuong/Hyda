/*
Hydraulic Functions for Hydra Controllers
HydraMega Family: hydramega 50 & hydramega 1612 boards
TC LIFTING EQUIPMENT CO., LTD
https://tcevn.vn
*/
#include <Arduino.h>
#include "hydraulic.h"
//extern unsigned long hydaCycleTime;
//===============================================================================================================
//===============================================================================================================
/*
jsIn from 0 - 100
lowRange < highRange
normal operation for solenoid valve, duty of pwm at start could be 30% and end at 80 %.
*/
float jsDutyRange(bool jsActivated, float jsIn, float lowRange, float highRange) {
	float dutyOut = 0;
	if ((jsActivated == true) && (jsIn >= 0) && (jsIn <= 100.0) && (lowRange >= 0) && (lowRange < highRange) && (highRange <= 100.0)) {
		dutyOut = lowRange + (highRange - lowRange) * (jsIn) / 100.0;
	}
	else {
		dutyOut = 0;
	}
	return dutyOut;
}//end of jsDutyRange
//===============================================================================================================
//===============================================================================================================
//function of joystick calculation v1.0
//with input from joystick range: jsNeg0-jsNeg100, joystick in Negative direction, output = 0 - 100 Negative
//with input from joystick jsPos0 - jsPos100, Positive direction, output = 0 - 100 %.
//in middle range jsNeg0 - jsPos0, joystick in neutral !
//when outside of jsNeg100 and jsPos100, get error !

joystick jsScale(float jsIn, float jsNeg100, float jsNeg0, float jsPos0, float jsPos100) {
	joystick jsTem;
	float posOut = 0;
	float negOut = 0;
	bool posDir = false;
	bool negDir = false;
	bool neu = true;
	bool err = false;
	if ((jsIn >= 0) && (jsIn <= 100) && (jsNeg100 >= 0) && (jsNeg100 < jsNeg0) && (jsNeg0 < jsPos0) && (jsPos0 < jsPos100) && (jsPos100 <= 100)) {
		//thoa man cac dieu kien dau vao!
		//tinh toan gia tri ham tai day
		if ((jsIn >= jsNeg100) && (jsIn <= jsNeg0)) {
			//trong nguong X-
			negDir = true;
			negOut = 100.0 * (jsNeg0 - jsIn) / (jsNeg0 - jsNeg100);

		}
		else {
			negOut = 0;
			negDir = false;
		}
		//X+
		if ((jsIn >= jsPos0) && (jsIn <= jsPos100)) {
			posDir = true;
			posOut = 100.0 * (jsIn - jsPos0) / (jsPos100 - jsPos0);
		}
		else
		{
			posOut = 0;
			posDir = false;
		}
		//Neutral
		if ((jsIn > jsNeg0) && (jsIn < jsPos0)) {
			//neutral joystick
			neu = true;
		}
		else
		{
			neu = false;
		}
		//Error check
		if ((jsIn >= jsNeg100) && (jsIn <= jsPos100)) {
			//outside range
			err = false;
		}
		else
		{
			err = true;
		}
		//get outputs
		jsTem.jsPosOut = posOut;
		jsTem.jsNegOut = negOut;
		jsTem.jsPosDir = posDir;
		jsTem.jsNegDir = negDir;
		jsTem.jsNeu = neu;
		jsTem.jsErr = err;
	}
	else
	{
		//khong thoa man dk vao, set cac dau ra = 0
		jsTem.jsPosOut = 0;
		jsTem.jsNegOut = 0;
		jsTem.jsNegOut = false;
		jsTem.jsPosDir = false;
		jsTem.jsNeu = true;
		jsTem.jsErr = true;
	}
	return jsTem;
}
//===============================================================================================================
//=====================================RAM FUNCTION==============================================================
/*
Function to create Ram value from input value, use for joystick ....get smooth setpoint
inVal: input value
ramVal: output ram value
ramTimeUp = ms of time go up!
ramTimeDown = ms of time go down
deltaT = ms of 1 cycle of MCU, that is meaning function will be called each cycle of MCU
note: ramVal is function value.
*/
float rampGenerator(float inVal, float ramVal, float ramTimeUp, float ramTimeDown) {
	float upTem = 100.0 * float(hydaCycleTime) / ramTimeUp;
	float downTem = 100.0 * float(hydaCycleTime)/ ramTimeDown;
	if (ramVal > inVal + downTem) {
		//ram down
		ramVal = ramVal - downTem;
		if (ramVal < 0) ramVal = 0;
	}
	else if (ramVal < inVal - upTem) {
		//ram up
		ramVal = ramVal + upTem;
		if (ramVal > 100.0) ramVal = 100.0;
	}
	else {
		ramVal = inVal;
	}
	return ramVal;
}

//======================
