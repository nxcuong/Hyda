/*
Functions
for hyda BOARDS
TC LIFTING EQUIPMENT CO., LTD
https://tcevn.vn
*/
#include <Arduino.h>
#include "hydaFunc.h"

unsigned char DIN(unsigned char channelNumber){
//channel could used from 1 - 8 or symbol defined
//channel could use symbol defined like DI0, DI1,...
	unsigned char i = channelNumber;
	unsigned char value=0;
#if defined(HYDA_0810)	
	switch (i) {
	case 1:	//channel1
		value = digitalRead(DI1);
		break;
	case 2:	//channel2
		value = digitalRead(DI2);
		break;
	case 3:	//channel3
		value = digitalRead(DI3);
		break;
	case 4:	//channel4
		value = digitalRead(DI4);
		break;
	case 5:	//channel5
		value = digitalRead(DI5);
		break;
	case 6:	//channel6
		value = digitalRead(DI6);
		break;
	case 7:	//channel7
		value = digitalRead(DI7);
		break;
	case 8:	//channel8
		value = digitalRead(DI8);
		break;
	}
	return value;

#endif	//DEFINED hyda0810
}//end of digialRead func=====================================================================

void DOUT(uint8_t channel, uint8_t value) {
	//digital out from no.0 to 15
	uint8_t i = channel;
	//uint8_t value = valueToWrite;
#if defined(HYDA_0810)
	switch (i) {
	case 1://channel1
		digitalWrite(DO1, value);
		break;
	case 2:	//channel2
		digitalWrite(DO2, value);
		break;
	case 3:	//channel3
		digitalWrite(DO3, value);
		break;
	case 4:	//channel4
		digitalWrite(DO4, value);
		break;
	case 5:	//channel5
		digitalWrite(DO5, value);
		break;
	case 6:	//channel6
		digitalWrite(DO6, value);
		break;
	case 7:	//channel7
		digitalWrite(DO7, value);
		break;
	case 8:	//channel8
		digitalWrite(DO8, value);
		break;
	case 9:	//channel9
		digitalWrite(DO9, value);
		break;
	case 10:	//channel10
		digitalWrite(DO10, value);
		break;
	}
#endif
}//END OF DIGITALOUTPUT FUNC
//============================================================================================
//Function PWMOUT
#if defined(HYDA_0810)
//function pwmOutput only for hydramega50
void PWMOUT(uint8_t channelNumber, float duty) {
	uint8_t i = channelNumber;
	float tem = 0;
	if (duty > 100.0) duty = 100.0;
	if (duty < 0) duty = 0;

	switch (i){
		case 1: //channel 1 = OCR1A
			tem = duty * float(ICR1) / 100.0;
			OCR1A = int(tem);
			break;
		case 2://channel 2 = OCR3A
			tem = duty * float(ICR3) / 100.0;
			OCR3A = int(tem);
			break;
		case 3: //OCR1B
			tem = duty * float(ICR1) / 100.0;
			OCR1B = int(tem);
			break;
		case 4: //OCR3B
			tem = duty * float(ICR3) / 100.0;
			OCR3B = int(tem);
			break;
		case 5: //OCR1C
			tem = duty * float(ICR1) / 100.0;
			OCR1C = int(tem);
			break;
		case 6: //OCR3C
			tem = duty * float(ICR3) / 100.0;
			OCR3C = int(tem);
			break;
		case 7: //OCR4A
			tem = duty * float(ICR4) / 100.0;
			OCR4A = int(tem);
			break;
		case 8: //OCR4B
			tem = duty * float(ICR4) / 100.0;
			OCR4B = int(tem);
			break;
		case 9: //5A
			tem = duty * float(ICR5) / 100.0;
			OCR5A = int(tem);
			break;
		case 10: //timer 5B
			tem = duty * float(ICR5) / 100.0;
			OCR5B = int(tem);
			break;
	}
}
#endif	//END IF defined HYDA0810
//
unsigned int CUR(unsigned char channelNumber) {
	//current sense of DOs 1 -10
	unsigned int value;
//=============================define mega0810====================
#if defined(HYDA_0810)
	switch (channelNumber) {
	case 1:	//channel out 1
		value = analogRead(IS1);
		break;
	case 2:	//channel out 2
		value = analogRead(IS2);
		break;
	case 3:	//channel out 3
		value = analogRead(IS3);
		break;
	case 4:	//channel out 4
		value = analogRead(IS4);
		break;
	case 5:	//channel out 5
		value = analogRead(IS5);
		break;
	case 6:	//channel out 6
		value = analogRead(IS6);
		break;
	case 7:	//channel out 7
		value = analogRead(IS7);
		break;
	case 8:	//channel out 8
		value = analogRead(IS8);
		break;
	case 9:	//channel out 9
		value = analogRead(IS9);
		break;
	case 10:	//channel out 10
		value = analogRead(IS10);
		break;
	}
	return value;
#endif
}

unsigned char STA(unsigned char channelNo) {
	unsigned char value = 0;
#if defined(HYDA_0810)
	//unsigned char i = channelNo;

//BOARD 0810
//number of status 12 channels according of 12 DOs
	switch (channelNo) {
	case 1:	//status channel 1
		value = digitalRead(ST1);
		break;
	case 2:	//status channel 2
		value = digitalRead(ST2);
		break;
	case 3:	//status channel 3
		value = digitalRead(ST3);
		break;
	case 4:	//status channel 4
		value = digitalRead(ST4);
		break;
	case 5:	//status channel 5
		value = digitalRead(ST5);
		break;
	case 6:	//status channel 6
		value = digitalRead(ST6);
		break;
	case 7:	//status channel 7
		value = digitalRead(ST7);
		break;
	case 8:	//status channel 8
		value = digitalRead(stDO8);
		break;
	case 9:	//status channel 9
		value = digitalRead(ST9);
		break;
	case 10:	//status channel 10
		value = digitalRead(ST10);
		break;
	}

#endif	//defined(HYDA_0810)
	return value;
}
//===========================================Timer setting for PWM out==========================
	/*we use TIMER 1, 3, 4, 5
			ch1 = ocr1A
			ch2 = ocr3A
			ch3 = ocr1b
			ch4 = ocr3b
			ch5 = ocr1c
			ch6 = ocr3c
			ch7 = ocr4a
			ch8 = ocr4b
			ch9 = ocr5a
			ch10 = ocr5b
	*/
void t1Config() {
	TCCR1A = 0x00; //clear registers
	TCCR1B = 0x00;
	OCR1A = 0;
	OCR1B = 0;
	OCR1C = 0;
	//setting registers
	TCCR1A |= _BV(COM1A1) | _BV(COM1B1) | _BV(COM1C1) | _BV(WGM11);
	TCCR1B |= _BV(WGM13) | _BV(WGM12) | _BV(CS10);
	ICR1 = 5710;
}
	
	
	
	//Timer 3 setting
void t3Config() {
	TCCR3A = 0x00; //clear registers
	TCCR3B = 0x00;
	OCR3A = 0;
	OCR3B = 0;
	OCR3C = 0;
	//setting registers
	TCCR3A |= _BV(COM3A1) | _BV(COM3B1) | _BV(COM3C1) | _BV(WGM31);
	TCCR3B |= _BV(WGM33) | _BV(WGM32) | _BV(CS30); 
	ICR3 = 5710; 
}

void t4Config() {
	//Timer 4 setting
	TCCR4A = 0x00; //clear registers
	TCCR4B = 0x00;
	OCR4A = 0; //clear outputs
	OCR4B = 0;
	OCR4C = 0;
	//setting registers
	TCCR4A |= _BV(COM4A1) | _BV(COM4B1) | _BV(COM4C1) | _BV(WGM41);
	TCCR4B |= _BV(WGM43) | _BV(WGM42) | _BV(CS40); //
	//ICR4 = 7999;
	ICR4 = 5000; //F = 3200HZ
}

void t5Config() {
	//Timer 5 setting
	TCCR5A = 0x00; //clear registers
	TCCR5B = 0x00;
	OCR5A = 0;
	OCR5B = 0;
	OCR5C = 0;
	//setting registers
	TCCR5A |= _BV(COM5A1) | _BV(COM5B1) | _BV(COM5C1) | _BV(WGM51);
	TCCR5B |= _BV(WGM53) | _BV(WGM52) | _BV(CS50); 
	//TCCR5B |= _BV(WGM53) | _BV(WGM52) | _BV(CS51); 
	//ICR5 = 5710;
	//ICR5 = 7999; //f = 2kHz
	//ICR5 = 15999; // f = 1kHz
	ICR5 = 5000; // f = 3200Hz
}
//====================================================================end of Timer settings
//FUNCTIONS OF PWM OUT SETTING
//1. setting pwm mode
//2. setting f_pwm
//3. setting dither amtitude - not apply in this version
//4. setting f_dither - not apply in this version
void PWM1_SETUP(unsigned int pwmFreq) {
	TCCR1A = 0x00; //clear registers
	TCCR1B = 0x00;
	OCR1A = 0;
	OCR1B = 0;
	OCR1C = 0;
	//setting registers
	TCCR1A |= _BV(COM1A1) | _BV(COM1B1) | _BV(COM1C1) | _BV(WGM11);
	//TCCR3B |= _BV(WGM33) | _BV(WGM32) | _BV(CS30); 
	if (pwmFreq < 50)	pwmFreq = 50;
	if (pwmFreq > 10000)	pwmFreq = 10000;

	if (pwmFreq >= 50 && pwmFreq <= 250) {
		TCCR1B |= _BV(WGM13) | _BV(WGM12) | _BV(CS11);
		//tinh ICR1
		ICR1 = int(float(16000000) / float(8 * pwmFreq)) - 1;
	}
	else if (pwmFreq > 250 && pwmFreq <= 10000)
	{
		TCCR1B |= _BV(WGM13) | _BV(WGM12) | _BV(CS10);
		ICR1 = int(float(16000000) / float(pwmFreq)) - 1;
	}

}//end pwm1_setup


void PWM3_SETUP(unsigned int pwmFreq) {
	TCCR3A = 0x00; //clear registers
	TCCR3B = 0x00;
	OCR3A = 0;
	OCR3B = 0;
	OCR3C = 0;
	//setting registers
	TCCR3A |= _BV(COM3A1) | _BV(COM3B1) | _BV(COM3C1) | _BV(WGM31);
	//TCCR3B |= _BV(WGM33) | _BV(WGM32) | _BV(CS30); 
	if (pwmFreq < 50)	pwmFreq = 50;
	if (pwmFreq > 10000)	pwmFreq = 10000;
	
	if (pwmFreq >= 50 && pwmFreq <= 250) {
		TCCR3B |= _BV(WGM33) | _BV(WGM32) | _BV(CS31);
		//tinh ICR3
		ICR3 = int(float(16000000) / float(8 * pwmFreq)) - 1;
	}
	else if (pwmFreq > 250 && pwmFreq <= 10000)
	{
		TCCR3B |= _BV(WGM33) | _BV(WGM32) | _BV(CS30); 
		ICR3 = int(float(16000000) / float(pwmFreq)) - 1;
	}
	
}//end pwm3_setup
void PWM4_SETUP(unsigned int pwmFreq) {
	TCCR4A = 0x00; //clear registers
	TCCR4B = 0x00;
	OCR4A = 0;
	OCR4B = 0;
	OCR4C = 0;
	//setting registers
	TCCR4A |= _BV(COM4A1) | _BV(COM4B1) | _BV(COM4C1) | _BV(WGM41);
	if (pwmFreq < 50)	pwmFreq = 50;
	if (pwmFreq > 10000)	pwmFreq = 10000;

	if (pwmFreq >= 50 && pwmFreq <= 250) {
		TCCR4B |= _BV(WGM43) | _BV(WGM42) | _BV(CS41);
		//tinh ICR4
		ICR4 = int(float(16000000) / float(8 * pwmFreq)) - 1;
	}
	else if (pwmFreq > 250 && pwmFreq <= 10000)
	{
		TCCR4B |= _BV(WGM43) | _BV(WGM42) | _BV(CS40); 
		ICR4 = int(float(16000000) / float(pwmFreq)) - 1;
	}

}//end pwm4_setup

void PWM5_SETUP(unsigned int pwmFreq) {
	TCCR5A = 0x00; //clear registers
	TCCR5B = 0x00;
	OCR5A = 0;
	OCR5B = 0;
	OCR5C = 0;
	//setting registers
	TCCR5A |= _BV(COM5A1) | _BV(COM5B1) | _BV(COM5C1) | _BV(WGM51);
	if (pwmFreq < 50)	pwmFreq = 50;
	if (pwmFreq > 10000)	pwmFreq = 10000;

	if (pwmFreq >= 50 && pwmFreq <= 250) {
		TCCR5B |= _BV(WGM53) | _BV(WGM52) | _BV(CS51); 
		//tinh ICR5
		ICR5 = int(float(16000000) / float(8 * pwmFreq)) - 1;
	}
	else if (pwmFreq > 250 && pwmFreq <= 10000)
	{
		TCCR5B |= _BV(WGM53) | _BV(WGM52) | _BV(CS50); 
		ICR5 = int(float(16000000) / float(pwmFreq)) - 1;
	}

}//end pwm5_setup

//======================
