/*
 * Copyright (c) 2021, TC LIFTING EQUIPMENT CO., LTD
 * All rights reserved.
 */

#ifndef __HYDRAULIC_H__
#define __HYDRAULIC_H__
#include <Arduino.h>
//#include <hyda.h>	//header file of hydramega family
//===========================================================
extern unsigned long hydaCycleTime;        //cycle time of mcu as global variable
/*Function for Joystick

jsIn = value of joystick input, range 0-100.0, you have to scale of analog value to range 0-100
jsNeg100 = value of joystick when output = 100 (%)
jsNeg0 = value of joystick when output = 0
jsPos0 = value of joystick in positive direction when output = 0
jsPos100 = value of jotstick in Positive direction when output = 100
*/
typedef struct {
    float	jsPosOut;//js positive output scale 0-100
    float	jsNegOut;
    bool    jsPosDir;
    bool    jsNegDir;
    bool	jsNeu;//js in neutral
    bool	jsErr; //error, outside range
} joystick;
joystick jsScale(float jsIn, float jsNeg100, float jsNeg0, float jsPos0, float jsPos100);
/*
jsValue from ANALOG INPUT 0-4096 <> 0-5V = 0-100 (%)
return value 0 - 100 for both direction Pos and Negative
*/
float jsDutyRange(bool jsActivated, float jsIn, float lowRange, float highRange);
/*
jsIn from 0 - 100
return range: lowRange TO highRange
normal operation for solenoid valve duty of pwm at start could be 30% and end at 80 %...
*/
//RAM FUNCTION
//input real 0-100.0
//ramTime up = time of out signal go from 0 - 100
//ramTime down = time of output signal go from 100 - 0
//output 0-100.0
float rampGenerator(float inVal, float ramVal, float ramTimeUp, float ramTimeDown);
#endif