/*
Hydra Timer functions operating as general PLCs Timers
ON_DELAY, OFF_DELAY, PULSE,...
HydraMega Family: hydramega 50 & hydramega 1612 boards
TC LIFTING EQUIPMENT CO., LTD
https://tcevn.vn
*/
/*V1. has enable signal for enable the timer
If en = false, reset timer
out = false
et = 0
*/
//#include <Arduino.h>
#include <hydaTimer.h>

//=====================================================================================
//on delay timer function
hydTimer TON(hydTimer tDT)
{
	if (tDT.en) {
		//do timer function
		if (tDT.in) {
			tDT.et = tDT.et + hydaCycleTime;
			if (tDT.et >= tDT.pt) {
				tDT.et = tDT.pt;
				tDT.out = true;
			}
			else
			{
				tDT.out = false;
			}
		}
		else
		{
			tDT.et = 0;
			tDT.out = false;
		}	
	}
	else {
		//reset timer
		tDT.out = false;
		tDT.et = 0;
	}
	return tDT;
	
}
//ON DELAY TIMER
//used pointer
//hydTimer pTON(hydTimer* ton) {		//1
hydTimer pTON(hydTimer * ton) {
	if (ton->en) {
		//timer func.
		if (ton->in) {
			ton->et = ton->et + hydaCycleTime;
			ton->out = true;
			if (ton->et >= ton->pt) {
				ton->et = ton->pt;
			}
			else
			{
				ton->out = false;
			}
		}
		else
		{
			ton->et = 0;
			ton->out = false;
		}
		//return *ton;		//1 return *ton is OK khi khai bao ton la kieu con tro
		
	}
	else {
		//reset timer
		ton->out = false;
		ton->et = 0;
	}
	return *ton;		//return
}

//=====================================================================================
//OFF DELAY TIMER FUNCTION
hydTimer TOFF(hydTimer tOT) {
	if (tOT.en) {
		//off delay function
		if (!tOT.in) {
			//go from 1 >> 0, out are 1
			if (tOT.out) {
				tOT.et += hydaCycleTime;
				if (tOT.et >= tOT.pt) {
					tOT.out = false;
					tOT.et = tOT.pt; //stop timer
				}
			}
			else
			{
				tOT.et = 0;
				//? set out = 0
			}
		}
		else
		{
			tOT.out = true;
			tOT.et = 0;	//reset et time
		}		
	}
	else {
		//reset timer
		tOT.out = false;
		tOT.et = 0;
	}
	return tOT;
}//END OF OFF DELAY FUNCTION
//======================================================================================
//PULSE FUNCTION CREATE ONE SHOT PULSE IN PT TIME WHEN IN IS ON.
hydTimer TP(hydTimer pulse) {
	if (pulse.en) {
		if (pulse.in) {
			//timer is on
			pulse.out = true;				//out is ON
			pulse.et += hydaCycleTime;		//increase et time
			if (pulse.et >= pulse.pt) {
				//reset out
				pulse.out = false;
				pulse.et = pulse.pt;
			}
		}
		else
		{
			pulse.et = 0;
			pulse.out = false;
		}
	}
	else {
		pulse.et = 0;
		pulse.out = false;
	}
	return pulse;
}//end of TP func
//=======================================================================================
hydTimer TFLASH(hydTimer* tf) {			//flashing
	if (tf->en) {
		if (tf->in) {
			tf->et += hydaCycleTime;		//increase time
			if (tf->et > tf->pt) {
				//over pt time
				tf->out = !(tf->out);
				tf->et = 0;
			}
		}
		else
		{
			tf->et = 0;
			tf->out = false;
		}
	}
	else {
		tf->et = 0;
		tf->out = false;
	}
	return *tf;
}
//=======================================================================================
//=======================================================================================
//TDP    function will create a pulse signal ON = tON time, OFF = tOFF time
//Timer single Pulse
hydTimer TSP(hydTimer* tsp, unsigned int tON, unsigned int tOFF) {
	if (tsp->en) {
		//check in signal
		if (tsp->in) {
			//pusch out = 1
			tsp->out = true;
			//increase et
			tsp->et += hydaCycleTime;
			//check et
			if (tsp->et >= tON) {
				//clear out
				tsp->out = false;
				//when et > tON + tOFF
				//reset et
				if (tsp->et >= (tON + tOFF)) {
					tsp->et = 0;		//recycle 
				}
			}
		}
		else
		{
			tsp->et = 0;
			tsp->out = false;
		}
	}
	else
	{
		tsp->et = 0;
		tsp->out = false;
	}
	return *tsp;
}
//=======================================================================================
hydTimer nTSP(hydTimer tsp, unsigned int tON, unsigned int tOFF) {
	if (tsp.en) {
		//check in signal
		if (tsp.in) {
			//pusch out = 1
			tsp.out = true;
			//increase et
			tsp.et += hydaCycleTime;
			//check et
			if (tsp.et >= tON) {
				//clear out
				tsp.out = false;
				//when et > tON + tOFF
				//reset et
				if (tsp.et >= (tON + tOFF)) {
					tsp.et = 0;		//recycle 
				}
			}
		}
		else
		{
			tsp.et = 0;
			tsp.out = false;
		}
	}
	else
	{
		tsp.et = 0;
		tsp.out = false;
	}
	return tsp;
}
//=======================================================================================

//TDP    function will create two pulses signal ON = tON time, OFF = tOFF time
//Timer double Pulses
//ton1, ton2 = time ON of pluses
//toff1 = time OFF of n1 pulses
//toff2 = time OFF of n2 pluses
//default ON time of pluse will be 250ms
//hydTimer TDP(hydTimer* tdp, unsigned int ton1, unsigned int toff1, unsigned n1, unsigned int ton2, unsigned int toff2, unsigned int n2) {
	
//}
	 