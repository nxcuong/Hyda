/*hydramega boards hardware configuration and initiation
by TC Lifting equipment co., ltd
Hai Phong City - Viet Nam
*/
#include <Arduino.h>
//#include <pins_arduino.h>
#include "hyda.h"

//==========================================initiation of Hyda board ==========================
void hydaInit() {
#if defined(HYDA_0810)
	//=====================================init for hyda0810 board
	pinMode(CANINT, INPUT); //CAN interrupt
	pinMode(SLOT1, OUTPUT);	//IO SS1
	pinMode(SLOT2, OUTPUT); //IO SS2
	pinMode(MAINSWITCH, OUTPUT); //main switch as output
	//SET SS ARE HIGH
	digitalWrite(SLOT1, HIGH);
	digitalWrite(SLOT2, HIGH);
	digitalWrite(MAINSWITCH, LOW);	//innit low
	//=============================================================
	//8 DIs
	pinMode(DI1, INPUT);
	pinMode(DI2, INPUT);
	pinMode(DI3, INPUT);
	pinMode(DI4, INPUT);
	pinMode(DI5, INPUT);
	pinMode(DI6, INPUT);
	pinMode(DI7, INPUT);
	pinMode(DI8, INPUT);
	//pinMode(DI9, INPUT);
	//pinMode(DI10, INPUT);
	//pinMode(DI11, INPUT);
	//pinMode(DI12, INPUT);
	//pinMode(DI13, INPUT);
	//pinMode(DI14, INPUT);
	//pinMode(DI15, INPUT);
	//pinMode(DI16, INPUT);
	//10 DOs
	pinMode(DO1, OUTPUT);
	pinMode(DO2, OUTPUT);
	pinMode(DO3, OUTPUT);
	pinMode(DO4, OUTPUT);
	pinMode(DO5, OUTPUT);
	pinMode(DO6, OUTPUT);
	pinMode(DO7, OUTPUT);
	pinMode(DO8, OUTPUT);
	pinMode(DO9, OUTPUT);
	pinMode(DO10, OUTPUT);
	//pinMode(DO11, OUTPUT);
	//pinMode(DO12, OUTPUT);
	//preset all OFF
	digitalWrite(DO1, LOW);
	digitalWrite(DO2, LOW);
	digitalWrite(DO3, LOW);
	digitalWrite(DO4, LOW);
	digitalWrite(DO5, LOW);
	digitalWrite(DO6, LOW);
	digitalWrite(DO7, LOW);
	digitalWrite(DO8, LOW);
	digitalWrite(DO9, LOW);
	digitalWrite(DO10, LOW);
	//digitalWrite(DO11, LOW);
	//digitalWrite(DO12, LOW);

	//10 Status of DOs as Digital inputs
	pinMode(ST1, INPUT);
	pinMode(ST2, INPUT);
	pinMode(ST3, INPUT);
	pinMode(ST4, INPUT);
	pinMode(ST5, INPUT);
	pinMode(ST6, INPUT);
	pinMode(ST7, INPUT);
	pinMode(ST8, INPUT);
	pinMode(ST9, INPUT);
	pinMode(ST10, INPUT);
	//pinMode(stDO11, INPUT);
	//pinMode(stDO12, INPUT);
	//====================================
	//10 Current sense channels = analog inputs
	pinMode(IS1, INPUT);
	pinMode(IS2, INPUT);
	pinMode(IS3, INPUT);
	pinMode(IS4, INPUT);
	pinMode(IS5, INPUT);
	pinMode(IS6, INPUT);
	pinMode(IS7, INPUT);
	pinMode(IS8, INPUT);
	pinMode(IS9, INPUT);
	pinMode(IS10, INPUT);
	//pinMode(iSenseDO11, INPUT);
	//pinMode(iSenseDO12, INPUT);

#endif // defined(HYDA_0810)

}	//END OF hydA


